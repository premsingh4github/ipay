
<?php echo isset($content) ? $content : Template::content(); ?>