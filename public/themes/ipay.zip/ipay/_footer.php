        <footer>
            <div class="copyright">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 sub-footer">
                            <ul>
                                <li><a href="#">iPay</a></li>
                                <li><a href="#">Privacy and Terms</a></li>
                                <li><a href="#">FAQ</a></li>
                            </ul>
                        </div>
                        <div class="col-md-6 text-right">Copyright © 2014</div>
                    </div>
                </div>
            </div>
        </footer>    


        <script src="<?php echo base_url(); ?>themes/ipay/js/plugins.js" defer></script>
        <script src="<?php echo base_url(); ?>themes/ipay/js/main.js" defer></script>


    </body>
</html>